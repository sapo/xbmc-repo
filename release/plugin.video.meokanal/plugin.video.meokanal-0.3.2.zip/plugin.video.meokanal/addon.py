import sys
import os.path
import requests

sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'resources/lib'))

from xbmcswift2 import Plugin
from xbmcswift2 import xbmc, xbmcgui, xbmcaddon
from datetime import datetime, timedelta
from xml.dom.minidom import parseString

import urllib
import CommonFunctions as common

import HTMLParser, cgi

# Show qrcode window definitions
# Should be closed after anykey
class QRCodePopupWindow(xbmcgui.WindowDialog):
    def __init__(self, linha1, linha2, linha3, qrcodefile):
        XBFONT_LEFT = 0x00000000
        XBFONT_RIGHT = 0X00000001
        XBFONT_CENTER_X = 0X00000002
        XBFONT_CENTER_Y = 0X00000004
        XBFONT_TRUNCATED = 0X00000008

        # Relative resolutions to 1920x1080 (1080p)
        self.setCoordinateResolution(0)

        self.addControl(xbmcgui.ControlImage(x=0, y=0, width=1920, height=1080, filename=os.path.join(MEDIADIR, "background_qrcode.png")))
        #self.addControl(xbmcgui.ControlImage(x=610, y=190, width=700, height=800, filename=os.path.join(MEDIADIR, "background_qrcode.png")))
        self.addControl(xbmcgui.ControlImage(x=710, y=240, width=500, height=500, filename=qrcodefile))
        self.addControl(xbmcgui.ControlLabel(x=610, y=760, width=700, height=25, label=linha1, alignment=XBFONT_CENTER_X))
        self.addControl(xbmcgui.ControlLabel(x=610, y=800, width=700, height=25, label=linha2, alignment=XBFONT_CENTER_X))
        self.addControl(xbmcgui.ControlLabel(x=610, y=840, width=700, height=25, label=linha3, alignment=XBFONT_CENTER_X))
        self.button0 = xbmcgui.ControlButton(x=710, y=890, width=500, height=50, label='OK', alignment=XBFONT_CENTER_X | XBFONT_CENTER_Y)
        self.addControl(self.button0)
        self.setFocus(self.button0)

    def onAction(self, action):
        ACTION_PREVIOUS_MENU = 10
        ACTION_SELECT_ITEM = 7
        if action == ACTION_PREVIOUS_MENU or action == ACTION_SELECT_ITEM:
            self.close()

    def onControl(self, control):
        if control == self.button0:
            self.close()


plugin = Plugin()
storage = plugin.get_storage(name='storage', file_format='pickle', TTL=None)
#print "==================================================================================="
#print "Current storage:"
#print storage.raw_dict()
#print "==================================================================================="

OAUTH_CONSUMER_KEY = '826f7d5f8f036adc78495de30e2df96f324dcb0b99ac4ef12cd75369e842f1e1'
OAUTH_CONSUMER_SECRET = '15320a90ee7d0f2634a55fb1e382ee27e1afd92779bbd054d11911d27ec49d9b'

OAUTH_REQUEST_TOKEN_URL = 'http://services.sapo.pt/IPTV/MEO/Kanal/api/oauth/out_of_band'
OAUTH_VALIDATE_PIN_URL = 'http://services.sapo.pt/IPTV/MEO/Kanal/api/oauth/validate_pin'
OAUTH_ACCESS_TOKEN_URL = 'https://meocloud.pt/oauth/access_token'

PUNY_URL = 'http://services.sapo.pt/PunyURL/GetCompressedURLByURL'

MEOKANAL_API_URL = 'http://services.sapo.pt/IPTV/MEO/Kanal/api'

ADDONID = 'plugin.video.meokanal'
settings = xbmcaddon.Addon(id=ADDONID)
addonfolder = settings.getAddonInfo('path')
addonname = settings.getAddonInfo('name')
addonicon = settings.getAddonInfo('icon')

resourcefolder = os.path.join(addonfolder, 'resources', 'icons')

MEDIADIR = os.path.join(xbmc.translatePath(settings.getAddonInfo('path')),'resources', 'media')

rsession = requests.Session()

language = settings.getLocalizedString
dbg = settings.getSetting("settings.debug") == "true"
temporary_path = xbmc.translatePath(settings.getAddonInfo('profile'))

def isLogo(logo):
    if logo:
        return logo
    else:
        return os.path.join(resourcefolder, 'icon.png')


@plugin.route('/')
def index():
    plugin.log.info(plugin.request.args)
    if 'oauth_access_token' in storage:
        has_login = True
    else:
        has_login = False

    items = []
    if has_login:

        menuitems = [
        {
            'label': language(30050),
            'path': plugin.url_for('editorial_picks'),
            'thumbnail': os.path.join(resourcefolder, 'menu_editorial_picks.png')
        },
        {
            'label': language(30051),
            'path': plugin.url_for('tops'),
            'thumbnail': os.path.join(resourcefolder, 'menu_tops.png')
        },
        {
            'label': language(30052),
            'path': plugin.url_for('categories'),
            'thumbnail': os.path.join(resourcefolder, 'menu_categories.png')
        },
        {
            'label': language(30053),
            'path': plugin.url_for('favorites'),
            'thumbnail': os.path.join(resourcefolder, 'menu_favorites.png')
        },
        {
            'label': language(30054),
            'path': plugin.url_for('watchlater'),
            'thumbnail': os.path.join(resourcefolder, 'menu_watchlater.png')
        },
        {
            'label': language(30055),
            'path': plugin.url_for('watchNow'),
            'thumbnail': os.path.join(resourcefolder, 'menu_watchnow.png')
        },
        {
            'label': language(30056),
            'path': plugin.url_for('notifications'),
            'thumbnail': os.path.join(resourcefolder, 'menu_notifications.png')
        },
        {
            'label': language(30058),
            'path': plugin.url_for('mykanais'),
            'thumbnail': os.path.join(resourcefolder, 'menu_mykanais.png')
        },
        {
            'label': language(30057),
            'path': plugin.url_for('logout'),
            'thumbnail': os.path.join(resourcefolder, 'menu_logout.png')
        }
        ]
        for i in menuitems:
            items.append(i)
    else:
        menuitems = {
            'label': 'Login',
            'path': plugin.url_for('login'),
            'thumbnail': os.path.join(resourcefolder, 'menu_login.png')
        }
        items.append(menuitems)

        # Force login if we don't have auth info
        #url = plugin.url_for('login')
        #plugin.redirect(url)

    xbmc.executebuiltin("Container.SetViewMode(500)")
    return items


@plugin.route('/editorial_picks')
def editorial_picks():
    resp_list = rsession.get(MEOKANAL_API_URL + '/channels/highlights?offset=0&limit=100')
    plugin.log.info('Requesting %s' % resp_list.url)

    if resp_list.status_code == 200:
        api_res = resp_list.json()

        items=[]
        for entry in api_res['data']['channels']:
            items.append( {
                'label': '%s - %s' % (entry['channel_number'], entry['title']),
                'path': plugin.url_for( endpoint='watchAsOnTV', 
                                        channel_id=entry['channel_id'], 
                                        logo=isLogo(entry['logo'])
                                    ),
                'thumbnail': isLogo(entry['logo'])
                })

        xbmc.executebuiltin("Container.SetViewMode(500)")
        return items
    else:
        plugin.notify(msg=language(30021), title=language(30012), delay=5000)


@plugin.route('/tops')
def tops():
    resp_list = rsession.get(MEOKANAL_API_URL + '/channels/top?offset=0&limit=100')
    plugin.log.info('Requesting %s' % resp_list.url)

    if resp_list.status_code == 200:
        api_res = resp_list.json()

        items=[]
        for entry in api_res['data']['channels']:
            items.append( {
                'label': '%s - %s' % (entry['channel_number'], entry['title']),
                'path': plugin.url_for(endpoint='watchAsOnTV', 
                                       channel_id=entry['channel_id'], 
                                       logo=isLogo(entry['logo'])
                                    ),
                'thumbnail': isLogo(entry['logo'])
                })

        xbmc.executebuiltin("Container.SetViewMode(500)")
        return items
    else:
        plugin.notify(msg=language(30021), title=language(30012), delay=5000)


@plugin.route('/mykanais')
def mykanais():
    resp_list = rsession.get(MEOKANAL_API_URL + '/channels', params = {'access_token': storage['oauth_access_token']})
    plugin.log.info('Requesting %s' % resp_list.url)

    if resp_list.status_code == 200:
        api_res = resp_list.json()

        items=[]
        for entry in api_res['data']['channels']:
            items.append( {
                'label': '%s - %s' % (entry['channel_number'], entry['title']),
                'path': plugin.url_for(endpoint='watchAsOnTV', 
                                       channel_id=entry['channel_id'], 
                                       logo=isLogo(entry['logo'])
                                    ),
                'thumbnail': isLogo(entry['logo'])
                })

        xbmc.executebuiltin("Container.SetViewMode(500)")
        return items
    else:
        plugin.notify(msg=language(30021), title=language(30012), delay=5000)

@plugin.route('/categories')
def categories():
    resp_list = rsession.get(MEOKANAL_API_URL + '/channels/categories')
    plugin.log.info('Requesting %s' % resp_list.url)

    if resp_list.status_code == 200:
        api_res = resp_list.json()

        items=[]
        for entry in api_res['data']['categories']:
            thumb =  os.path.join(resourcefolder, 'cat_%s.png' % entry['category_id'])

            if not os.path.exists(thumb):
                thumb =  os.path.join(resourcefolder, 'cat_default.png')

            items.append( {
                'label': entry['name'].encode('utf-8'),
                'path': plugin.url_for(endpoint='channelsByCategory', category_id=entry['category_id']),
                'thumbnail': thumb
                })
    
        xbmc.executebuiltin("Container.SetViewMode(500)")
        return items
    else:
        plugin.notify(msg=language(30021), title=language(30012), delay=5000)


@plugin.route('/channelsByCategory<category_id>')
def channelsByCategory(category_id):
    plugin.log.info('Request to channelsByCategory with %s' % category_id)
    resp_list = rsession.get(MEOKANAL_API_URL + '/channels/categories/%s?limit=100' % category_id)
    plugin.log.info('Requesting %s' % resp_list.url)

    if resp_list.status_code == 200:
        api_res = resp_list.json()

        items=[]
        for entry in api_res['data']['channels']:
            items.append( {
                'label': '%s - %s' % (entry['channel_number'], entry['title']),
                'path': plugin.url_for(endpoint='watchAsOnTV', 
                                       channel_id=entry['channel_id'], 
                                       logo=isLogo(entry['logo'])
                                    ),
                'thumbnail': isLogo(entry['logo'])
                })

        xbmc.executebuiltin("Container.SetViewMode(500)")
        return items
    else:
        plugin.notify(msg=language(30021), title=language(30012), delay=5000)


@plugin.route('/favorites')
def favorites():
    if not 'oauth_access_token' in storage:
        url = plugin.url_for('login')
        plugin.redirect(url)

    params = { 'access_token': storage['oauth_access_token'] }
    resp_list = rsession.get(MEOKANAL_API_URL + '/channels/favorites', params = params)
    plugin.log.info('Requesting %s' % resp_list.url)

    if resp_list.status_code == 200:
        api_res = resp_list.json()

        items=[]
        for entry in api_res['data']['channels']:
            items.append( {
                'label': '%s - %s' % (entry['channel_number'], entry['title']),
                'path': plugin.url_for(endpoint='watchAsOnTV', 
                                       channel_id=entry['channel_id'], 
                                       logo=isLogo(entry['logo'])
                                    ),
                'thumbnail': isLogo(entry['logo'])
                })

        xbmc.executebuiltin("Container.SetViewMode(500)")
        return items
    else:
        plugin.notify(msg=language(30021), title=language(30012), delay=5000)


@plugin.route('/watchlater')
def watchlater():
    if not 'oauth_access_token' in storage:
        url = plugin.url_for('login')
        plugin.redirect(url)

    params = { 'access_token': storage['oauth_access_token'] }
    resp_list = rsession.get(MEOKANAL_API_URL + '/channels/watchlater', params = params)
    plugin.log.info('Requesting %s' % resp_list.url)

    if resp_list.status_code == 200:
        api_res = resp_list.json()

        items=[]
        for entry in api_res['data']['channels']:
            items.append( {
                'label': '%s - %s' % (entry['channel_number'], entry['title']),
                'path': plugin.url_for(endpoint='watchAsOnTV', 
                                       channel_id=entry['channel_id'], 
                                       logo=isLogo(entry['logo'])
                                    ),
                'thumbnail': isLogo(entry['logo'])
                })

        xbmc.executebuiltin("Container.SetViewMode(500)")
        return items
    else:
        plugin.notify(msg=language(30021), title=language(30012), delay=5000)


@plugin.route('/watchAsOnTV <channel_id> <logo>')
def watchAsOnTV(channel_id, logo):
    if not 'oauth_access_token' in storage:
        url = plugin.url_for('login')
        plugin.redirect(url)

    params = { 'access_token': storage['oauth_access_token'] }
    resp_list = rsession.get(MEOKANAL_API_URL + '/channels/' + channel_id + '/schedule', params = params)
    plugin.log.info('Requesting %s' % resp_list.url)
    api_res = resp_list.json()

    if resp_list.status_code == 200:

        items=[]
        for entry in api_res['data']['videos']:
            items.append( {
            'label': '%s' % entry['title'],
            'path': entry['mov_url'],
            'thumbnail': logo,
            'is_playable': True
            })

        playlist = xbmc.PlayList( xbmc.PLAYLIST_VIDEO )
        playlist.clear()

        plugin.add_to_playlist(items, playlist='video')
        xbmc.Player().play(playlist)

        return items
    
    else:
        plugin.notify(msg=language(30023), title=language(30012), delay=5000)


@plugin.route('/watchNow')
def watchNow():
    if not 'oauth_access_token' in storage:
        url = plugin.url_for('login')
        plugin.redirect(url)

    channel_no = common.getUserInputNumbers(language(30028))

    if len(channel_no) == 0:
        plugin.notify(msg=language(30022), title=language(30012), delay=5000)
    
    else:
        plugin.log.info('Request to watchNow with %s' % channel_no)

        # First try with public search (no access_token)
        resp_list = rsession.get(MEOKANAL_API_URL + '/channels?q=%s' % channel_no)
        plugin.log.info('Requesting %s' % resp_list.url)

        try:
            api_res = resp_list.json()
            results = api_res['data']['items_in_response']
        except:
            plugin.log.info('No results on public search. Reverting to private')
            # We had no results, so we try searching for private channels
            resp_list = rsession.get(MEOKANAL_API_URL + '/channels?q=%s' % channel_no, 
                                     params = {'access_token': storage['oauth_access_token']})
            plugin.log.info('Requesting %s' % resp_list.url)


        if resp_list.status_code == 200:
            api_res = resp_list.json()

            try:

                if api_res['data']['items_in_response'] == 1:
                    channel_id = api_res['data']['channels'][0]['channel_id']
                    schannel_no = api_res['data']['channels'][0]['channel_number']
                    channel_privacy = api_res['data']['channels'][0]['privacy']
                    channel_type = api_res['data']['channels'][0]['type']
                    channel_logo = api_res['data']['channels'][0]['icon']

                    if (channel_no == schannel_no) and (channel_type == 'playlist'):

                        watchAsOnTV(channel_id, channel_logo)

                    else:
                        plugin.notify(msg=language(30023), title=language(30012), delay=5000)
                else:
                    plugin.notify(msg=language(30023), title=language(30012), delay=5000)
            except:
                plugin.notify(msg=language(30023), title=language(30012), delay=5000)
        else:
            plugin.notify(msg=language(30023), title=language(30012), delay=5000)
    

    url = plugin.url_for('index')
    plugin.redirect(url)



#@plugin.route('/playOneVideo <url> <title>')
#def playOneVideo(url, title):
#
#    h = HTMLParser.HTMLParser()
#    title = h.unescape(title)
#
#    plugin.log.info('Request to playOneVideo with:\nurl: %s\ntitle: %s\n' % (url,title))
#
#    if not 'oauth_access_token' in storage:
#        url = plugin.url_for('login')
#        plugin.redirect(url)
#
#    li = xbmcgui.ListItem(label=addonname, 
#                          iconImage=addonicon, 
#                          thumbnailImage=os.path.join(resourcefolder, 'icon.png'), 
#                          path=url)
#    li.setInfo(type='Video', infoLabels={ "Title": title })
#    li.setProperty('IsPlayable', 'true')
#
#    xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(item=url, listitem=li)
#
#
#
#@plugin.route('/viewChannel<channel_id>')
#def viewChannel(channel_id):
#    plugin.log.info('Request to viewChannel with %s' % channel_id)
#    if not 'oauth_access_token' in storage:
#        url = plugin.url_for('login')
#        plugin.redirect(url)
#
#    params = { 'access_token': storage['oauth_access_token'] }
#    resp_list = rsession.get(MEOKANAL_API_URL + '/channels/%s/schedule' % channel_id, params = params)
#    plugin.log.info('Requesting %s' % resp_list.url)
#
#    if resp_list.status_code == 200:
#    
#        api_res = resp_list.json()
#        total_videos = api_res['data']['total']['videos']
#
#        if total_videos > 0:
#    
#            items=[]
#            for entry in api_res['data']['videos']:
#                items.append( {
#                    'label': '%s' % entry['title'],
#                     #'path': entry['mov_url'],
#                    'path': plugin.url_for(endpoint='playOneVideo', 
#                                           url=entry['mov_url'], 
#                                           title=cgi.escape(entry['title'].encode('utf-8'))),
#                    'thumbnail': entry['thumb'],
#                    })
#    
#            xbmc.executebuiltin("Container.SetViewMode(50)")
#            return items
#        else:
#            plugin.notify(msg=language(30022), title=language(30012), delay=5000)
#    else:
#        plugin.notify(msg=language(30023), title=language(30012), delay=5000)


@plugin.route('/notifications')
def notifications():
    if not 'oauth_access_token' in storage:
        url = plugin.url_for('login')
        plugin.redirect(url)

    params = { 'access_token': storage['oauth_access_token'] }
    resp_list = rsession.get(MEOKANAL_API_URL + '/notifications', params = params)
    plugin.log.info('Requesting %s' % resp_list.url)

    if resp_list.status_code == 200:
        api_res = resp_list.json()
        notifications = api_res['data']['notifications']

        h = HTMLParser.HTMLParser()

        items=[]
        for entry in notifications:
            items.append( {
                'label': '%s' % h.unescape(notifications[entry]['description']),
                'path': plugin.url_for(endpoint='index'),
                'is_playable': False
                })

        return items
    else:
        plugin.log.error(resp_list.text)
        plugin.notify(msg=language(30021), title=language(30012), delay=5000)


@plugin.route('/logout')
def logout():
    if 'oauth_access_token' in storage:
        del storage['oauth_access_token']

    settings.setSetting("settings.user.name", language(30026))
    settings.setSetting("settings.user.email", 'n/a')

    url = plugin.url_for('index')
    plugin.redirect(url)


@plugin.route('/login')
def login():
    plugin.log.info(plugin.request.args)

    # phase 1 - obtain authorization URL
    payload = {
                'client_id':     OAUTH_CONSUMER_KEY, 
                'client_secret': OAUTH_CONSUMER_SECRET, 
                'scope[0]':      'videos.list',
                'scope[1]':      'channel.list',
                'scope[2]':      'schedule.list',
                'scope[3]':      'notifications.list'
    }

    resp_list = rsession.post(MEOKANAL_API_URL + '/oauth/out_of_band', data=payload)
    plugin.log.info('Requesting %s' % resp_list.url)

    if resp_list.status_code == 200:
        api_res = resp_list.json()
        myhash = api_res['hash']
        authorization_url = api_res['url']
        plugin.log.info('Authorization URL: {0}'.format(authorization_url))

        # phase 2 - compress URL and show it
        expires = (datetime.now() + timedelta(hours=1)).isoformat()
        puny_params = {'url': authorization_url, 'random': '1', 'expires': expires}
        
        retry_counter = 3

        while retry_counter > 0:
            resp_puny = rsession.get(PUNY_URL, params=puny_params)
            plugin.log.info('Requesting %s' % resp_puny.url)
            if resp_puny.status_code == 200:
                break
            plugin.log.info('Error %s while punyfing URL: %s' % (resp_puny.status_code, resp_puny.text))
            retry_counter -= 1

        if retry_counter == 0:
            plugin.notify(msg=language(30021), title=language(30012), delay=5000)
            url = plugin.url_for('index')
            plugin.redirect(url)

        compressed_url = parseString(resp_puny.content).getElementsByTagName('ascii')[0].childNodes[0].nodeValue

        # Show qrcode along with URL
        import tempfile
        qrcodefile = tempfile.gettempdir() + '/' + 'meocloudQRCode.jpg'

        import pyqrcode
        qr_image = pyqrcode.MakeQRImage(compressed_url, rounding = 5, fg = "black", bg = "White", br = False)
        qr_image.save(qrcodefile)

        qrwindow = QRCodePopupWindow(language(30008), compressed_url, language(30009), qrcodefile)
        qrwindow.doModal()
        del qrwindow

        # phase 3 - obtain verifier
        verifier = common.getUserInputNumbers(language(30010))
        plugin.log.info('Got verifier: {0}'.format(verifier))

        if len(verifier) == 0:
            plugin.notify(msg=language(30015), title=language(30012), delay=5000)
        else:
            # phase 4 - obtain authenticated access token
            payload = {
                    'client_id':     '826f7d5f8f036adc78495de30e2df96f324dcb0b99ac4ef12cd75369e842f1e1', 
                    'client_secret': '15320a90ee7d0f2634a55fb1e382ee27e1afd92779bbd054d11911d27ec49d9b', 
                    'pin':            verifier,
                    'hash':           myhash
                    }

            resp_list = rsession.post(MEOKANAL_API_URL + '/oauth/validate_pin', data=payload)
            plugin.log.info('Requesting %s' % resp_list.url)

            if resp_list.status_code == 200:
                api_res = resp_list.json()
                access_token = api_res['access_token']
                storage['oauth_access_token'] = access_token

                resp_list = rsession.get(MEOKANAL_API_URL + '/account', params={'access_token': access_token})
                plugin.log.info('Requesting %s' % resp_list.url)
                api_res = resp_list.json()

                if resp_list.status_code == 200:
                    settings.setSetting("settings.user.name", api_res['data'][1]['name'])
                    settings.setSetting("settings.user.email", api_res['data'][1]['email'])
                else:
                    settings.setSetting("settings.user.name", language(30027))
                    settings.setSetting("settings.user.email", 'n/a')

                url = plugin.url_for('index')
                plugin.redirect(url)

            else:
                plugin.notify(msg=language(30025), title=language(30012), delay=5000)
    else:
        plugin.notify(msg=language(30021), title=language(30012), delay=5000)


if __name__ == '__main__':
    plugin.run()
